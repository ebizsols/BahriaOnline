=====Languages=========

Copy languages files from theme and plugins and then paste in your theme and plugins.

---For Theme

Listingo > languages > paste your files

---For listingo_core

listingo_core > languages > paste your files

---For listingo_vc_shortcodes

listingo_vc_shortcodes > languages > paste your files

-------------------------------------------------------------

Please note all files are already present in themes and plugin.