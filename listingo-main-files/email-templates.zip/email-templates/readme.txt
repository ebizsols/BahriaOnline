--------------Email templates

In template folder all email template HTML is available, Just copy and paste in theme settings for each email.

In Html folder there are email views, from which you can capture any view like, Buttons, listing strips etc.

For more information you can contact us at our support forum : https://themographics.ticksy.com/